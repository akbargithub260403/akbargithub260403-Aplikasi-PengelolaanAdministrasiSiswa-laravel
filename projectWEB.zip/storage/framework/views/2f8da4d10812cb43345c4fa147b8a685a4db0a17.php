
<?php $__env->startSection('judul','Detail | Siswa'); ?>
<?php $__env->startSection('judulContent','Detail Siswa'); ?>
<?php $__env->startSection('halamanJurusan','active'); ?>

<?php $__env->startSection('content'); ?>

<!-- /.row -->
<div class="row">
    <div class="col-lg-4">
        <div class="panel panel-green">
            <div class="panel-heading">
                Data Siswa
            </div>
            <div class="panel-body">
            <img src="<?php echo e($student->getAvatar()); ?>" height="130px;" width="130px;" class="card-img-top" style="border-radius: 50%;" alt="...">
                <ul class="list-group list-group-flush">
                    <li class="list-group-item">NISN        : <?php echo e($student->NISN); ?> </li>
                    <li class="list-group-item">Nama        : <?php echo e($student->nama); ?> </li>
                    <li class="list-group-item">Kelas       : <?php echo e($student->kelas); ?> </li>
                    <li class="list-group-item">Jurusan     : <?php echo e($student->jurusan); ?> </li>
                    <li class="list-group-item">Email       : <?php echo e($student->email); ?> </li>
                    <li class="list-group-item">No Telepon  : <?php echo e($student->no_telp); ?> </li>
                    <li class="list-group-item">Alamat      : <?php echo e($student->alamat); ?> </li>
                </ul>
            </div>
            <div class="panel-footer">
                    <a href="<?php echo e('/update-data/'.$student->id); ?>" style="margin-bottom: 10px;" class=" d-inline btn btn-outline btn-warning ">Update Data</a>
                    <form action="<?php echo e('/delete-data/'.$student->id); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                        <button class="btn btn-outline btn-danger ">Delete Data</button>
                    </form>
            </div>
        </div>
        <!-- /.col-lg-4 -->
    </div>
    <div class="col-lg-8">
        <div class="panel panel-primary">
            <div class="panel-heading">
                Administrasi Siswa
            </div>
            <div class="panel-body">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Tanggal</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td></td>
                                <td></td>
                                <td></td>
                            </tr>
                        </tbody>
                    </table>
            </div>
            <div class="panel-footer">
                <a href="" class="btn btn-success">Export</a>
                <button type="button" class="btn btn-primary " data-toggle="modal" data-target="#myModal">
                    Tambah Data Administrasi
                </button>
            </div>
        </div>
        <!-- /.col-lg-4 -->
    </div>
</div>

 <!-- Modal -->
 <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title" id="myModalLabel">Modal title</h4>
            </div>
            <div class="modal-body">
                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary">Save changes</button>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
                                    <!-- /.modal -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\FRAMEWORK_PHP\Laravel\laravel7\project\projectWEB\resources\views/pages/detail-siswa.blade.php ENDPATH**/ ?>