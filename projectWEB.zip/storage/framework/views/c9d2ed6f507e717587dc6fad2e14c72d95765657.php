<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title><?php echo $__env->yieldContent('judul'); ?></title>
    <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/metisMenu.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/timeline.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/startmin.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/morris.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/font-awesome.min.css')); ?>" rel="stylesheet" type="text/css">
    <script src="<?php echo e(asset('js/html5shiv.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/respond.min.js')); ?>"></script>

    <?php echo $__env->yieldContent('cssLuar'); ?>

</head>
<body>

    <div id="wrapper">

        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">

            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>

            <ul class="nav navbar-nav navbar-left navbar-top-links">
                <li><a href="<?php echo e('/'); ?>"><i class="fa fa-home fa-fw"></i> Aplikasi Pengelolaan Administrasi Siswa</a></li>
            </ul>

            <ul class="nav navbar-right navbar-top-links">
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-user fa-fw"></i> Setting <b class="caret"></b>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        <li>
                            <a href="#"><i class="fa fa-user fa-fw"></i> <?php echo e(Auth::user()->name); ?></a>
                        </li>
                        <li class="divider"></li>
                        <li class="dropdown">
                            <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                onclick="event.preventDefault();
                                document.getElementById('logout-form').submit();">
                                    <i class="fa fa-sign-out fa-fw"></i><?php echo e(__('Logout')); ?>

                            </a>
                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                <?php echo csrf_field(); ?>
                            </form>
                        </li>
                    </ul>
                </li>
            </ul>

            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        <li>
                            <center>
                                <h4 class="d-inline-block"><i>APADS</i>
                                    <img src="<?php echo e(asset('/img/logo.png')); ?>" width="40" height="40" alt="">
                                </h4>
                            </center>
                        </li>
                        <li>
                            <a href="<?php echo e('/home'); ?>" class="<?php echo $__env->yieldContent('dashboard'); ?>"><i class="fa fa-dashboard fa-fw"></i> Dashboard</a>
                        </li>
                        <li>
                            <a href="<?php echo e('/tambah-siswa'); ?>" class="<?php echo $__env->yieldContent('tambahSiswa'); ?>"><i class="fa fa-edit fa-fw"></i> Tambah Data Siswa</a>
                        </li>
                        <li>
                            <a href="<?php echo e('/jurusan-students/'.'RPL'); ?>" class="<?php echo $__env->yieldContent('halamanJurusan'); ?>"><i class="fa fa-graduation-cap"></i> Jurusan</a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="<?php echo e('/jurusan-students/'.'RPL'); ?>">Rekayasa Perangkat Lunak</a>
                                </li>
                                <li>
                                    <a href="<?php echo e('/jurusan-students/'.'TKJ'); ?>">Teknik Komputer Jaringan</a>
                                </li>
                                <li>
                                    <a href="<?php echo e('/jurusan-students/'.'KI'); ?>">Kimia Industri</a>
                                </li>
                                <li>
                                    <a href="<?php echo e('/jurusan-students/'.'BDP'); ?>">Bisnis Dan Pemasaran</a>
                                </li>
                                <li>
                                    <a href="<?php echo e('/jurusan-students/'.'ATPH'); ?>">Agribisnis Tanaman Pangan Dan Horticultura</a>
                                </li>
                                <li>
                                    <a href="<?php echo e('/jurusan-students/'.'TEI'); ?>">Teknik Elektronik Industri</a>
                                </li>
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                    </ul>
                </div>
            </div>
        </nav>

        <div id="page-wrapper">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header"><?php echo $__env->yieldContent('judulContent'); ?></h1>
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <!-- /.panel -->
        <div class="panel panel-default">
            <div class="panel-heading">
                <i class="fa fa-clock-o fa-fw"></i> <?php echo $__env->yieldContent('judulContent'); ?>
            </div>
            <!-- /.panel-heading -->
            <div class="panel-body">
                <div class="content">
                    <?php echo $__env->yieldContent('content'); ?>
                </div>
            </div>
        <!-- /.panel-body -->
    </div>
    <!-- /.panel -->
</div>
</div>
<!-- /.col-lg-4 -->
</div>
<!-- /.row -->
</div>
<!-- /.container-fluid -->
</div>

        
    </div>

<script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/metisMenu.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/raphael.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/morris.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/morris-data.js')); ?>"></script>
<script src="<?php echo e(asset('js/startmin.js')); ?>"></script>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\FRAMEWORK_PHP\Laravel\laravel7\project\projectWEB\resources\views/layouts/main.blade.php ENDPATH**/ ?>