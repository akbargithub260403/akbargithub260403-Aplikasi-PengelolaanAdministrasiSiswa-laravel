
<?php $__env->startSection('judul','Halaman Data Siswa'); ?>
<?php $__env->startSection('judulContent','File Data Siswa'); ?>
<?php $__env->startSection('dataSiswa','active'); ?>

<?php $__env->startSection('content'); ?>

<table class="table table-dark table-bordered table-hover ">
    <thead>
        <tr>
            <th>#</th>
            <th>Nama File</th>
            <th>Keterangan</th>
            <th>Tanggal Data Masuk</th>
        </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($loop->iteration); ?></td>
            <td><a href="<?php echo e(asset('/file/'.$dt->data_file)); ?>"><?php echo e($dt->data_file); ?></a></td>
            <td><?php echo e($dt->keterangan); ?></td>
            <td><?php echo e($dt->created_at); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\FRAMEWORK_PHP\laravel7\project\projectWEB\resources\views/pages/dataSiswa.blade.php ENDPATH**/ ?>