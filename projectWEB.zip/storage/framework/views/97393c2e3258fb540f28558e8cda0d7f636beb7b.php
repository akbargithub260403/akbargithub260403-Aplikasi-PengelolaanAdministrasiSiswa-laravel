<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title><?php echo $__env->yieldContent('judul'); ?></title>
    <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/metisMenu.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/timeline.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/startmin.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/morris.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/font-awesome.min.css')); ?>" rel="stylesheet" type="text/css">
    <script src="<?php echo e(asset('js/html5shiv.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/respond.min.js')); ?>"></script>

</head>
<body>

    <div id="wrapper">

        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <div class="navbar-header">
                <a class="navbar-brand" href="<?php echo e('/'); ?>">Application</a>
            </div>

            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>

            <ul class="nav navbar-nav navbar-left navbar-top-links">
                <li><a href="<?php echo e('/'); ?>"><i class="fa fa-home fa-fw"></i> Laravel</a></li>
            </ul>

            <ul class="nav navbar-right navbar-top-links">
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-user fa-fw"></i> Setting <b class="caret"></b>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        <li><a href="#"><i class="fa fa-user fa-fw"></i> User Profile</a>
                        </li>
                        <li class="divider"></li>
                        <li><a href="login.html"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                        </li>
                    </ul>
                </li>
            </ul>

            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        <li class="sidebar-search">
                            <h4>Laravel 7</h4>
                        </li>
                        <li>
                            <a href="<?php echo e('/'); ?>" class="active"><i class="fa fa-dashboard fa-fw"></i> Dashboard</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>

        <div id="page-wrapper">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">Dashboard</h1>
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <!-- /.panel -->
        <div class="panel panel-default">
            <div class="panel-heading">
                <i class="fa fa-clock-o fa-fw"></i> Responsive Timeline
            </div>
            <!-- /.panel-heading -->
            <div class="panel-body">
                <div class="content">
                    <?php echo $__env->yieldContent('content'); ?>
                </div>
        </div>
        <!-- /.panel-body -->
    </div>
    <!-- /.panel -->
</div>
</div>
<!-- /.col-lg-4 -->
</div>
<!-- /.row -->
</div>
<!-- /.container-fluid -->
</div>

        
    </div>

<script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/metisMenu.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/raphael.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/morris.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/morris-data.js')); ?>"></script>
<script src="<?php echo e(asset('js/startmin.js')); ?>"></script>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\FRAMEWORK_PHP\laravel7\project\projectWEB\resources\views/templates/main.blade.php ENDPATH**/ ?>