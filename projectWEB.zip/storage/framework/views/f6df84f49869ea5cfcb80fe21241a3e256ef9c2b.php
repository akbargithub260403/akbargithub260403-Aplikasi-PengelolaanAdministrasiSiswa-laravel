
<?php $__env->startSection('judul',$jurusan); ?>
<?php $__env->startSection('judulContent',$jurusan); ?>
<?php $__env->startSection('halamanJurusan','active'); ?>

<?php $__env->startSection('content'); ?>
<div class="jumbotron jumbotron-fluid">
  <div class="container">
    <center><img src="<?php echo e($gambar); ?>" style="border-radius: 50%;" width="150px;" height="150px;" alt=""></center>
    <h2 class="display-4"><?php echo e($jurusan); ?></h2>
     <p style="font-size:15px;"><?php echo e($keterangan); ?></p>
     <?php if(session('status')): ?>
    <div class="alert alert-success alert-dismissible">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&nbsp;</button>
        <?php echo e(session('status')); ?> &nbsp; <a href="#" class="alert-link">Berhasil</a>.
    </div>
    <?php endif; ?>
  </div>
</div>
<!-- /.col-lg-6 -->
<div class="col">
    <div class="panel tabbed-panel panel-primary">
        <div class="panel-heading clearfix">
            <div class="panel-title pull-left">Tabel Data Siswa</div>
            <div class="pull-right">
                <ul class="nav nav-tabs">
                    <li  class="active"><a href="#tab-primary-4" data-toggle="tab">Semua Kelas</a></li>
                    <li><a href="#tab-primary-1" data-toggle="tab">Kelas X</a></li>
                    <li><a href="#tab-primary-2" data-toggle="tab">Kelas XI</a></li>
                    <li><a href="#tab-primary-3" data-toggle="tab">Kelas XII</a></li>
                </ul>
            </div>
        </div>
        <div class="panel-body">
            <div class="tab-content">
                <div class="tab-pane fade in active" id="tab-primary-4">
                <form action="<?php echo e('/search-dataSiswa/'.$namaJurusan); ?>" method="post" style="margin-bottom:10px;" class="d-inline col-md-6">
                    <?php echo csrf_field(); ?>
                    <label for="" ><i>Cari Data Siswa</i></label>
                    <input type="text" name="keyword" class="form-control" autocomplete="off" placeholder="Search Engine">
                </form>
                     <table class="table" >
                        <thead>
                            <tr style="background-color: #228B22;">
                                <th style="color:white;">#</th>
                                <th style="color:white;">NISN</th>
                                <th style="color:white;">Nama Siswa</th>
                                <th style="color:white;">Kelas</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($dt->NISN); ?></td>
                                <td><?php echo e($dt->nama); ?></td>
                                <td><?php echo e($dt->kelas); ?></td>
                                <td><a href="<?php echo e('/detail/'.$dt->id.'/'.$dt->NISN); ?>" class="btn btn-outline btn-info btn-xs">Detail</a></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <div class="tab-pane fade " id="tab-primary-1">
                     <table class="table" >
                        <thead>
                            <tr style="background-color: #228B22;">
                                <th style="color:white;">#</th>
                                <th style="color:white;">NISN</th>
                                <th style="color:white;">Nama Siswa</th>
                                <th style="color:white;">Kelas</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $dataX; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($dt->NISN); ?></td>
                                <td><?php echo e($dt->nama); ?></td>
                                <td><?php echo e($dt->kelas); ?></td>
                                <td><a href="<?php echo e('/detail/'.$dt->id.'/'.$dt->NISN); ?>" class="btn btn-outline btn-info btn-xs">Detail</a></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <div class="tab-pane fade" id="tab-primary-2">
                     <table class="table" >
                        <thead>
                            <tr style="background-color: #228B22;">
                                <th style="color:white;">#</th>
                                <th style="color:white;">NISN</th>
                                <th style="color:white;">Nama Siswa</th>
                                <th style="color:white;">Kelas</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $dataXI; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($dt->NISN); ?></td>
                                <td><?php echo e($dt->nama); ?></td>
                                <td><?php echo e($dt->kelas); ?></td>
                                <td><a href="<?php echo e('/detail/'.$dt->id.'/'.$dt->NISN); ?>" class="btn btn-outline btn-info btn-xs">Detail</a></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <div class="tab-pane fade" id="tab-primary-3">
                     <table class="table" >
                        <thead>
                            <tr style="background-color: #228B22;">
                                <th style="color:white;">#</th>
                                <th style="color:white;">NISN</th>
                                <th style="color:white;">Nama Siswa</th>
                                <th style="color:white;">Kelas</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $dataXII; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($dt->NISN); ?></td>
                                <td><?php echo e($dt->nama); ?></td>
                                <td><?php echo e($dt->kelas); ?></td>
                                <td><a href="<?php echo e('/detail/'.$dt->id.'/'.$dt->NISN); ?>" class="btn btn-outline btn-info btn-xs">Detail</a></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <!-- /.panel -->
</div>
<!-- /.col-lg-6 -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\FRAMEWORK_PHP\Laravel\laravel7\project\projectWEB\resources\views/pages/halaman-jurusan.blade.php ENDPATH**/ ?>