<?php
header("Content-type: application/vnd-ms-excel");
header("Content-Disposition: attachment; filename=Data Siswa Jurusan $jurusan .xls");
?>
<h1><center>Data Siswa Jurusan <?= $jurusan; ?></center></h1>
<table border=1>
    <thead class="thead-dark">
        <tr>
            <th>#</th>
            <th>NISN</th>
            <th>Nama</th>
            <th>Kelas</th>
            <th>Jurusan</th>
            <th>Email</th>
            <th>Alamat</th>
            <th>No Telepon</th>
            <th>Tanggal Data Masuk</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th scope="row"><?php echo e($loop->iteration); ?></th>
                <td><?php echo e($dt->NISN); ?></td>
                <td><?php echo e($dt->nama); ?></td>
                <td><?php echo e($dt->kelas); ?></td>
                <td><?php echo e($dt->jurusan); ?></td>
                <td><?php echo e($dt->email); ?></td>
                <td><?php echo e($dt->alamat); ?></td>
                <td><?php echo e($dt->no_telp); ?></td>
                <td><?php echo e($dt->created_at); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /**PATH C:\xampp\htdocs\FRAMEWORK_PHP\laravel7\project\projectWEB\resources\views/export/exportdataSiswaXLS.blade.php ENDPATH**/ ?>