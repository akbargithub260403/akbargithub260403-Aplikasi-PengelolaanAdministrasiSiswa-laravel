<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan Data Siswa <?php echo e($jurusan); ?></title>
    <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">
</head>

<style>
    @media  print {
        .tombolPrint {
            display: none;
        }
    }

</style>

<body>
    <center><img src="<?php echo e(asset('/img/logo.png')); ?>" alt="" height="150px;" width="120px;" style="opacity:0.5;"></center>
    <div class="container">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>#</th>
                    <th>NISN</th>
                    <th>Nama</th>
                    <th>Kelas</th>
                    <th>Jurusan</th>
                    <th>Alamat</th>
                    <th>Email</th>
                    <th>No Telepon</th>
                    <th>Tanggal Data Masuk</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($dt->NISN); ?></td>
                    <td><?php echo e($dt->nama); ?></td>
                    <td><?php echo e($dt->kelas); ?></td>
                    <td><?php echo e($dt->jurusan); ?></td>
                    <td><?php echo e($dt->alamat); ?></td>
                    <td><?php echo e($dt->email); ?></td>
                    <td><?php echo e($dt->no_telp); ?></td>
                    <td><?php echo e($dt->created_at); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <button onclick="window.print()" class="tombolPrint btn btn-info">Print Disini</button>
    </div>


</body>

</html>
<?php /**PATH C:\xampp\htdocs\FRAMEWORK_PHP\laravel7\project\projectWEB\resources\views/export/exportdataSiswaPDF2.blade.php ENDPATH**/ ?>