
<?php $__env->startSection('judul','Detail | Siswa'); ?>
<?php $__env->startSection('judulContent','Detail Siswa'); ?>
<?php $__env->startSection('halamanJurusan','active'); ?>

<?php $__env->startSection('content'); ?>

<!-- /.row -->
<div class="row">
    <div class="col-lg-4">
        <div class="panel panel-green">
            <div class="panel-heading">
                Data Siswa
            </div>
            <div class="panel-body">
                <img src="<?php echo e($student->getAvatar()); ?>" height="130px;" width="130px;" class="card-img-top"
                    style="border-radius: 50%;" alt="...">
                <ul class="list-group list-group-flush">
                    <li class="list-group-item">NISN : <?php echo e($student->NISN); ?> </li>
                    <li class="list-group-item">Nama : <?php echo e($student->nama); ?> </li>
                    <li class="list-group-item">Kelas : <?php echo e($student->kelas); ?> </li>
                    <li class="list-group-item">Jurusan : <?php echo e($student->jurusan); ?> </li>
                    <li class="list-group-item">Email : <?php echo e($student->email); ?> </li>
                    <li class="list-group-item">No Telepon : <?php echo e($student->no_telp); ?> </li>
                    <li class="list-group-item">Alamat : <?php echo e($student->alamat); ?> </li>
                </ul>
            </div>
            <div class="panel-footer">
                <a href="<?php echo e('/update-data/'.$student->id); ?>" style="margin-bottom: 10px;"
                    class=" d-inline btn btn-outline btn-warning ">Update Data</a>
                <form action="<?php echo e('/delete-data/'.$student->id); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('delete'); ?>
                    <button class="btn btn-outline btn-danger ">Delete Data</button>
                </form>
            </div>
        </div>
        <!-- /.col-lg-4 -->
    </div>
    <div class="col-lg-8">
        <div class="panel panel-primary">
            <div class="panel-heading">
                Administrasi Siswa
            </div>
            <div class="panel-body">

            <!-- Pesan Berhasil atau gagal -->
                <?php if(session('status')): ?>
                <div class="alert alert-info alert-dismissible">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&nbsp;</button>
                    <?php echo e(session('status')); ?> &nbsp; <a href="#" class="alert-link">Berhasil</a>.
                </div>
                <?php endif; ?>

                <table class="table">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Tanggal</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $administrasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($ad->tanggal); ?></td>
                            <td>
                                <form action="<?php echo e('/Hapus-Administrasi/'.$ad->id); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('delete'); ?>
                                    <button class="btn btn-danger">Delete</button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <div class="panel-footer">
                <a href="<?php echo e('/exportAdministrasi/'.$student->nama.'/'.$student->NISN); ?>" target="_blank"  class="btn btn-success">Export</a>
                <button type="button" class="btn btn-primary " data-toggle="modal" data-target="#myModal">
                    Tambah Data Administrasi
                </button>
            </div>
        </div>
        <!-- /.col-lg-4 -->
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title" id="myModalLabel">Administrasi</h4>
            </div>
            <div class="modal-body">
                <form action="<?php echo e('/tambahPembayaranAdministrasi/'.$student->NISN); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="exampleInputEmail1">Tanggal Pembayaran</label>
                        <input type="text" class="form-control" name="tanggal" id="exampleInputEmail1"
                            aria-describedby="emailHelp">
                        <small id="emailHelp" class="form-text text-muted">Masukan Tanggal Sesuai Dengan Hari
                            ini.</small>
                    </div>
                    <button type="submit" class="btn btn-primary">Submit</button>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\FRAMEWORK_PHP\laravel7\project\projectWEB\resources\views/pages/detail-siswa.blade.php ENDPATH**/ ?>