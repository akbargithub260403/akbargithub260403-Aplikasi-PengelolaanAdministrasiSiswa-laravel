<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan Administrasi <?php echo e($namaSiswa); ?></title>
    <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">
</head>

<style>
    @media  print{
        .tombolPrint{
            display: none;
        }
    }
</style>

<body>

    <center><img src="<?php echo e(asset('/img/logo.png')); ?>" alt="" height="150px;" width="120px;" style="opacity:0.5;"></center>
    <div class="container">

        <table class="table table-bordered" cellpadding="8" border=1>
            <thead>
                <tr>
                    <th></th>
                    <td style="padding: 10px 50px">
                        <center><b>Data Siswa</b></center>
                    </td>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $dataSiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th rowspan="8" width="300px;"><center ><img style="margin-top:30px; border-radius:10px;" src="<?php echo e(asset('/img/gambar-siswa/'.$dt->gambar)); ?>" height="180px;" width="180px;" alt=""></center></th>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
                <?php $__currentLoopData = $dataSiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>NISN : <b><?php echo e($dt->NISN); ?></b></td>
                    </tr>
                    <tr>
                        <td>Nama : <b><?php echo e($dt->nama); ?></b></td>
                    </tr>
                    <tr>
                        <td>Kelas   : <b><?php echo e($dt->kelas); ?></b></td>
                    </tr>
                    <tr>
                        <td>Jurusan     : <b><?php echo e($dt->jurusan); ?></b></td>
                    </tr>
                    <tr>
                        <td>Email       : <b><?php echo e($dt->email); ?></b></td>
                    </tr>
                    <tr>
                        <td>Alamat      : <b><?php echo e($dt->alamat); ?></b></td>
                    </tr>
                    <tr>
                        <td>No Telepon  : <b><?php echo e($dt->no_telp); ?></b></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <hr>
        <table class="table table-bordered" border=1>
            <thead>
                <tr>
                    <th>#</th>
                    <th>Tanggal Pembayaran</th>
                    <th>Waktu Pembayaran</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $dataAdministrasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($dta->tanggal); ?></td>
                    <td><?php echo e($dta->created_at); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <button onclick="window.print()" class="tombolPrint btn btn-info">Print Disini</button>

    </div>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\FRAMEWORK_PHP\laravel7\project\projectWEB\resources\views/export/exportdataSiswaPDF.blade.php ENDPATH**/ ?>